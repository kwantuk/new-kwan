import Transaction from "./component/Transaction"
import FormComponent from "./component/FormComponent";
import './App.css'
import { useState } from "react";

function App() {
  const design={color:"red",textAlign:"center",forntZixe:'1.5rem'}
  
  // const initData = [
  //   {id:1,title:"กินข้าว",amount:666},
  //   {id:2,title:"ดูหนัง",amount:200}
   
  // ]
  
  // const [items,setItems] = useState(initData)
  const [items,setItems] = useState([])


  const onAddNewItem = (newItem)=>{
    setItems((prevItem)=>{
      return [newItem,newItem,newItem,newItem,newItem,...prevItem]
    }
    )
  }
  
  return(
   <div className="container">
      <h1 style={design}> โปรแกรมรายรับรายจ่าย </h1>
      <FormComponent onAddItem = {onAddNewItem}/>
      <Transaction items = {items}/>
   </div>

  )
}

export default App;
